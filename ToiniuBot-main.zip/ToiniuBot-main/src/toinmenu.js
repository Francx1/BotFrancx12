const toinmenu = (prefix, pushname) => {
    return `⧔𖤐ᩕ *COMANDO DO FRANCX*

⧔ᩕ ${prefix}setprefix
⧔ᩕ ${prefix}block
⧔ᩕ ${prefix}bc
⧔ᩕ ${prefix}bcgc
⧔ᩕ ${prefix}clearall`

}

exports.toinmenu = toinmenu